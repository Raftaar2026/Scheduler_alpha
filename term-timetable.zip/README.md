# Term Timetable

A single-page class-scheduling board for business school admin staff: a weekly
timetable grid with room/faculty conflict detection, plus screens to manage
course offerings, faculty and rooms.

It's a single static HTML file — no build step, no server, no dependencies
beyond two Google Fonts and a browser.

## Features

- **Weekly grid** — Mon–Fri, 6 periods a day by default. Click any empty
  period to schedule a class; click an existing class to edit or remove it.
- **Conflict detection** — double-booking a room or a faculty member in the
  same period flags both classes and warns you before you save. Enrollment
  over a room's capacity is flagged separately.
- **Unscheduled offerings panel** — anything without a class yet is listed
  with a one-click "Schedule" button.
- **Setup screen** — add, edit and remove course offerings, faculty and
  rooms, and update the term name.
- **Light/dark aware** — follows the visitor's OS theme.
- **Persistence** — the schedule is saved to the browser's `localStorage`,
  so a staff member's edits are still there next time they open the page in
  the same browser. There is no backend and no shared/multi-user sync; if
  you need several staff editing the same schedule at once, you'll want to
  wire the `persist()` and `loadState()` functions in `index.html` to a
  small backend or a service like Firebase/Supabase.

## Running it

Just open `index.html` in a browser, or serve the folder with any static
file server, e.g.:

```
npx serve .
```

## Deploying to GitHub Pages

1. Push this repo to GitHub.
2. In the repo settings, go to **Pages** and set the source to the `main`
   branch, root folder.
3. GitHub will publish the site at `https://<your-username>.github.io/<repo-name>/`.

## Customizing

Open `index.html` and edit the JSON inside the
`<script id="app-state" type="application/json">` block near the bottom —
that's the starting data (school name, term, days, periods, rooms, faculty
and course offerings). Everything after that is loaded from
`localStorage` once a staff member makes their first edit in a given
browser, so update the embedded JSON before first use if you want a
different starting dataset.

## License

MIT — see `LICENSE`.
